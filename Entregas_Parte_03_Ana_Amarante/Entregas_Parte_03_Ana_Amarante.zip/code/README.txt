Para executar a calculadora do LTE Release 10, siga os passos abaixo:
	1. Baixe todos os arquivos da pasta code e deixe o "calcTputLTE.m" na mesma pasta dos arquivos .csv.
	2. Abra "calcTputLTE.m" no MATLAB e execute.
	3. Preencha as entradas de acordo com suas preferências e clique no botão "CALCULAR". As saídas serão mostradas em seguida na interface da calculadora.